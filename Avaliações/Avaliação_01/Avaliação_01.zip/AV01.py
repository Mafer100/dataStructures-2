import quickSort as qs

toSort = [-11,-30,-6,-24,47,-2,46,-36,12,-36,15,29,-47,1,21]

result = qs.QuickSort(toSort,"f")
print(result)

result = qs.QuickSort(toSort,"l")
print(result)